import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AeronavesModule } from './modules/aerolineas/aeronaves.module';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./modules/home/home.module').then(m => m.HomeModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./modules/home/home.module').then(m => m.HomeModule),
    data: {
      breadcrumbs: 'Inicio'
    }
  },
  {
    path: 'aerolinea',
    loadChildren: () => import('./modules/aerolineas/aeronaves.module').then(m => m.AeronavesModule),
    data: {
      breadcrumbs: 'aeronaves'
    }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
