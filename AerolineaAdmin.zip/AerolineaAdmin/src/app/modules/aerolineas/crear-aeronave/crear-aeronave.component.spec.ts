import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearAeronaveComponent } from './crear-aeronave.component';

describe('CrearAeronaveComponent', () => {
  let component: CrearAeronaveComponent;
  let fixture: ComponentFixture<CrearAeronaveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CrearAeronaveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CrearAeronaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
