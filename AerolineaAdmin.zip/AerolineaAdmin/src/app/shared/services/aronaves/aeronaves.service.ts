import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Api } from '../../api/api';

@Injectable({
  providedIn: 'root'
})
export class AeronavesService {

  constructor(private http: HttpClient,private api: Api) 
  {
  }

  GetAll(){
    return this.api.get('api/Aircraft')
  }

  Post(objeto : any){
    const headers = new Headers({ 'Content-Type': 'application/json' });
    return this.api.post("api/Aircraft",objeto,  { headers: headers });
   }
}
