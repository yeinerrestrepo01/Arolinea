import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearPilotosComponent } from './crear-pilotos.component';

describe('CrearPilotosComponent', () => {
  let component: CrearPilotosComponent;
  let fixture: ComponentFixture<CrearPilotosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CrearPilotosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CrearPilotosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
