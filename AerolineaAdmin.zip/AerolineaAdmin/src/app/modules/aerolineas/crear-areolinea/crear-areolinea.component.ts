import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AerolineaService } from 'src/app/shared/services/aerolinea/aerolinea.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-crear-areolinea',
  templateUrl: './crear-areolinea.component.html',
  styleUrls: ['./crear-areolinea.component.scss'],
  providers: [FormBuilder]
})
export class CrearAreolineaComponent implements OnInit {

  public formGroup: FormGroup;
  public lisAerolineas: any[];

  constructor(
    private formBuilder: FormBuilder,
    private aerolineaService: AerolineaService,
    private toastr: ToastrService) {
  }

  ngOnInit(): void {
    this.formGroup = this.formBuilder.group({
      nombreinput: new FormControl("", [Validators.required]),
      pasiinput: new FormControl("", []),
      descripcioninput: new FormControl("", [])
    });

    this.getAll();
  }

  getAll() {
    this.aerolineaService.GetAll().subscribe((data: any) => {
      console.log(data);
      if (!data.IsError) {
        this.lisAerolineas = data.Result;
      }
    });
  }

  insertAirline() {
    let airline =
    {
      "PasiOrigen": this.formGroup.value.descripcioninput,
      "Descripcion": this.formGroup.value.pasiinput,
      "Nombre": this.formGroup.value.nombreinput,
    }
    if (!this.formGroup.valid) 
    {
      this.toastr.warning('Por favor validar los campos con *', 'Mensaje de notificacion!');
    } 
    else {
      this.aerolineaService.Post(airline).subscribe((data: any) => {
        if (!data.IsError) {
          this.toastr.success(data.Message, 'Mensaje de notificacion!');
          this.getAll();
        }
        else {
          this.toastr.error('Ocurrio un error inesperado por favor comunicarse con el administrador', 'Mensaje de notificacion!');
        };
      });
    }

  }

}
