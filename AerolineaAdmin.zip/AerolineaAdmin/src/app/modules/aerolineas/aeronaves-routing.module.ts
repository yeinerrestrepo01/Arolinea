import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CrearAeronaveComponent } from './crear-aeronave/crear-aeronave.component';
import { CrearAreolineaComponent } from './crear-areolinea/crear-areolinea.component';
import { BienvenidosComponent } from './bienvenidos/bienvenidos.component';
import { CrearPilotosComponent } from './crear-pilotos/crear-pilotos.component';
import { AlquilerAeronavesComponent } from './alquiler-aeronaves/alquiler-aeronaves.component';


const routes: Routes = [
  { path: 'bienvenidos', component:  BienvenidosComponent},
  { path: 'crear-aerolinea', component:  CrearAreolineaComponent},
  { path: 'crear-aeronave', component:  CrearAeronaveComponent},
  { path: 'crear-pilotos', component:  CrearPilotosComponent},
  { path: 'alquiler', component:  AlquilerAeronavesComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AeronavesRoutingModule { }
