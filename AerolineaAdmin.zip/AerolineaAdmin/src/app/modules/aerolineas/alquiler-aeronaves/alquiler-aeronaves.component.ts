import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AeronavesService } from 'src/app/shared/services/aronaves/aeronaves.service';
import { ToastrService } from 'ngx-toastr';
import { AlquilerService } from 'src/app/shared/services/alquiler/alquiler.service';

@Component({
  selector: 'app-alquiler-aeronaves',
  templateUrl: './alquiler-aeronaves.component.html',
  styleUrls: ['./alquiler-aeronaves.component.scss'],
  providers: [FormBuilder]
})
export class AlquilerAeronavesComponent implements OnInit {

  public formGroup: FormGroup;
  public lisAlquilar: any[];
  public lisAeronaves: any[];

  constructor(private formBuilder: FormBuilder,
    private aeronavesService: AeronavesService,
    private toastr: ToastrService,
    private alquilerService: AlquilerService) { }

  ngOnInit(): void {
    this.formGroup = this.formBuilder.group({
      inputUbicacion: new FormControl("", [Validators.required]),
      inputLlegada: new FormControl("", [Validators.required]),
      inputSalida: new FormControl("", [Validators.required]),
      inputCantidad: new FormControl("", [Validators.required]),
      inputAeronave: new FormControl("", [Validators.required])
    });
    this.getAlquilar();
    this.getAllAeronaves();
  }

  getAlquilar() {
    this.alquilerService.GetAll().subscribe((data: any) => {
      if (!data.IsError) {
        this.lisAlquilar = data.Result;
      }
    });
  }

  getAllAeronaves() {
    this.aeronavesService.GetAll().subscribe((data: any) => {
      if (!data.IsError) {
        console.log(data)
        this.lisAeronaves = data.Result;
      }
    });
  }

  insertAlquiler()
  {
    let alquiler = 
    {
       "DondeViaja":this.formGroup.value.inputUbicacion,
       "FechaLLegada":this.formGroup.value.inputLlegada,
       "FechaSalida":this.formGroup.value.inputSalida,
       "CantidadPasajetos":this.formGroup.value.inputCantidad,
    }
    if(!this.formGroup.valid)
    {
      this.toastr.warning('Por favor validar los campos con *', 'Mensaje de notificacion!');
    }else
    {
      this.alquilerService.Post(alquiler).subscribe((data: any) => {
        if (!data.IsError)
        {
          console.log(data);
          this.toastr.success(data.Message, 'Mensaje de notificacion!');
          this.getAlquilar();
        }
        else
        {
          this.toastr.error('Ocurrio un error inesperado por favor comunicarse con el administrador', 'Mensaje de notificacion!');
        };
      });
    }
  }
}
