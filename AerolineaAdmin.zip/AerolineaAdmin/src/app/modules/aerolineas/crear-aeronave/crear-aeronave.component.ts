import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AerolineaService } from 'src/app/shared/services/aerolinea/aerolinea.service';
import { PilotosService } from 'src/app/shared/services/pilotos/pilotos.service';
import { AeronavesService } from 'src/app/shared/services/aronaves/aeronaves.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-crear-aeronave',
  templateUrl: './crear-aeronave.component.html',
  styleUrls: ['./crear-aeronave.component.scss'],
  providers: [FormBuilder]
})
export class CrearAeronaveComponent implements OnInit {

  public formGroup: FormGroup;
  public lisAerolineas: any[];
  public lisPilotos: any[];
  public lisAeronaves: any[];

   constructor(
    private formBuilder: FormBuilder,
    private aerolineaService:AerolineaService,
    private pilotosService:PilotosService,
    private aeronavesService: AeronavesService,
    private toastr: ToastrService)
    {
    }

  ngOnInit(): void {
    this.formGroup = this.formBuilder.group({
      nombreInput: new FormControl("", [Validators.required]),
      serieInput: new FormControl("", [Validators.required]),
      modeloInput: new FormControl("", [Validators.required]),
      cantidadInput: new FormControl("", [Validators.required]),
      descripcionInput: new FormControl("", []),
      aerolineaInput: new FormControl("", [Validators.required]),
      pilotoInput: new FormControl("", [Validators.required]),
    });
    this.getAll();
    this.getAllPilotos();
    this.getAllAeronaves();
  }

  getAll() {
    this.aerolineaService.GetAll().subscribe((data: any) => {
      if (!data.IsError) 
      {
        this.lisAerolineas = data.Result; 
      }
    });
  }

  getAllPilotos() {
    this.pilotosService.GetAll().subscribe((data: any) => {
      if (!data.IsError) {
        this.lisPilotos = data.Result;
      }
    });
  }

  getAllAeronaves() {
    this.aeronavesService.GetAll().subscribe((data: any) => {
      if (!data.IsError) {
        this.lisAeronaves = data.Result;
      }
    });
  }


  insertAeronave()
  {
    let aeronave = 
    {
      "Nombre": this.formGroup.value.nombreInput,
      "Serie":this.formGroup.value.serieInput,
      "Capacidad":this.formGroup.value.cantidadInput,
      "Descripcion":this.formGroup.value.descripcionInput,
      "Arolinea":this.formGroup.value.aerolineaInput,
      "Piloto":this.formGroup.value.pilotoInput,
      "Modelo":this.formGroup.value.modeloInput
    };
     
    if(!this.formGroup.valid)
    {
      this.toastr.warning('Por favor validar los campos con *', 'Mensaje de notificacion!');
    }else
    {
      this.aeronavesService.Post(aeronave).subscribe((data: any) => {
        if (!data.IsError)
        {
          this.toastr.success(data.Message, 'Mensaje de notificacion!');
          this.getAllAeronaves();
        }
        else
        {
          this.toastr.error('Ocurrio un error inesperado por favor comunicarse con el administrador', 'Mensaje de notificacion!');
        };
      });
    }
    
  }
}
