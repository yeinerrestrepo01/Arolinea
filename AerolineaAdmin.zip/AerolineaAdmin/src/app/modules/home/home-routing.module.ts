import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BienvenidosComponent } from '../aerolineas/bienvenidos/bienvenidos.component';


const routes: Routes = [
  { path: '', component: BienvenidosComponent },
  { path: 'login', component: BienvenidosComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
