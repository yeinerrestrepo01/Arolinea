import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AerolineaService } from 'src/app/shared/services/aerolinea/aerolinea.service';
import { PilotosService } from 'src/app/shared/services/pilotos/pilotos.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-crear-pilotos',
  templateUrl: './crear-pilotos.component.html',
  styleUrls: ['./crear-pilotos.component.scss'],
  providers: [FormBuilder]
})
export class CrearPilotosComponent implements OnInit {

  public formGroup: FormGroup;
  public lisAerolineas: any[];
  public lisPilotos: any[];
 

  constructor(
    private formBuilder: FormBuilder,
    private aerolineaService: AerolineaService,
    private pilotosService: PilotosService,
    private toastr: ToastrService)
    {
    this.formGroup = this.formBuilder.group({
      documentoInput: new FormControl("", [Validators.required]),
      nombreInput: new FormControl("", [Validators.required]),
      apellidosInput: new FormControl("", [Validators.required]),
      direccionInput: new FormControl("", []),
      telefonoInput: new FormControl("", []),
      emailInput: new FormControl("", []),
      aerolienaInput: new FormControl("", []),
      paisInput: new FormControl("", []),
    });

    this.getAll();
    this.getAllPilotos();
  }

  ngOnInit(): void {
  }


  getAll() {
    this.aerolineaService.GetAll().subscribe((data: any) => {
      if (!data.IsError) {
        this.lisAerolineas = data.Result;
      }
    });
  }


  getAllPilotos() {
    this.pilotosService.GetAll().subscribe((data: any) => {
      if (!data.IsError) {
        this.lisPilotos = data.Result;
      }
    });
  }

  insertPilot(){

    let pilot = 
    {
      "Identificacion": this.formGroup.value.documentoInput,
      "Nombres":this.formGroup.value.nombreInput,
      "Apellidos":this.formGroup.value.apellidosInput,
      "Direccion":this.formGroup.value.direccionInput,
      "Telefono":this.formGroup.value.telefonoInput,
      "Email":this.formGroup.value.emailInput,
      "Aerolinea": Number(this.formGroup.value.aerolienaInput),
      "Pais":this.formGroup.value.paisInput,
    };

    if(this.formGroup.valid)
    {
        this.pilotosService.Post(pilot).subscribe((data: any) => {
        if (!data.IsError)
        {
          this.toastr.success(data.Message, 'Mensaje de notificacion!');
          this.getAllPilotos();
        }
        else
        {
          this.toastr.error(data.Message, 'Mensaje de notificacion!');
          alert(data.Message);
        };
      });
    }else
    {
      this.toastr.warning('Por favor validar los campos con *', 'Mensaje de notificacion!');
    }
    
  }
}
