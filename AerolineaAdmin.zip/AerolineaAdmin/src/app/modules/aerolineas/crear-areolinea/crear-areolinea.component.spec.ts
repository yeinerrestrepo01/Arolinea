import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearAreolineaComponent } from './crear-areolinea.component';

describe('CrearAreolineaComponent', () => {
  let component: CrearAreolineaComponent;
  let fixture: ComponentFixture<CrearAreolineaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CrearAreolineaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CrearAreolineaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
