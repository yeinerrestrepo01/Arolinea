import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AeronavesRoutingModule } from './aeronaves-routing.module';
import { CrearAeronaveComponent } from './crear-aeronave/crear-aeronave.component';
import { CrearAreolineaComponent } from './crear-areolinea/crear-areolinea.component';
import { BienvenidosComponent } from './bienvenidos/bienvenidos.component';
import { CrearPilotosComponent } from './crear-pilotos/crear-pilotos.component';
import { AlquilerAeronavesComponent } from './alquiler-aeronaves/alquiler-aeronaves.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
     CrearAeronaveComponent,
      CrearAreolineaComponent,
      BienvenidosComponent,
      CrearPilotosComponent,
      AlquilerAeronavesComponent],
  imports: [
    CommonModule,
    AeronavesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class AeronavesModule { }
