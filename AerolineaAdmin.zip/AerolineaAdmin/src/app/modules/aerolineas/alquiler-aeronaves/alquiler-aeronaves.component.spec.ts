import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlquilerAeronavesComponent } from './alquiler-aeronaves.component';

describe('AlquilerAeronavesComponent', () => {
  let component: AlquilerAeronavesComponent;
  let fixture: ComponentFixture<AlquilerAeronavesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlquilerAeronavesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlquilerAeronavesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
