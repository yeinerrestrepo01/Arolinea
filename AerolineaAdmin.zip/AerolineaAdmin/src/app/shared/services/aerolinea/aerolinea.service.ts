import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Api } from '../../api/api';

@Injectable({
  providedIn: 'root'
})
export class AerolineaService {

  constructor(private http: HttpClient,private api: Api) {
  }

  GetAll(){
    return this.api.get('api/Airline')
  }

  Post(objeto : any){
    const headers = new Headers({ 'Content-Type': 'application/json' });
    return this.api.post("api/Airline",objeto,  { headers: headers });
   }
}
